#ifdef __MAKECINT__

//#pragma link off all typedef;
#pragma link off all globals;
#pragma link off all functions;
#pragma link off all classes;

// #pragma link C++ class std::vector< double >+;
//#pragma link C++ class std::vector< std::vector< double > >+;
//#pragma link C++ class std::vector< std::vector< std::vector< double > > >+;

//#pragma link C++ namespace MySpace;
// #pragma link C++ nestedclass;
// #pragma link C++ nestedtypedef;

#pragma link C++ typedef FEBDTP_PKT;
#pragma link C++ class FEBDTP+;
//#pragma link C++ class std::vector< MyClass3 >+;
//#pragma link C++ class std::vector< std::vector< MyClass3 > >+;

#endif /* __MAKECINT__ */
