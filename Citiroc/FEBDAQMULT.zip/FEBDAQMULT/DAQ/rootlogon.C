#include "TROOT.h"
#include "TSystem.h"
void rootlogon()
{
gSystem->Load("libFEBDTP.so");
}
